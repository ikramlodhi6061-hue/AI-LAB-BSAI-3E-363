# AI Lab Assignment: Minimax and Alpha-Beta Pruning

TREE = {
    "Root": ["A", "B"],
    "A": ["A1", "A2"],
    "B": ["B1", "B2"]
}

LEAF_VALUES = {
    "A1": 3,
    "A2": 5,
    "B1": 2,
    "B2": 9
}


def minimax(node, maximizing, counter):
    if node in LEAF_VALUES:
        counter[0] += 1
        return LEAF_VALUES[node]

    values = []
    for child in TREE[node]:
        values.append(
            minimax(child, not maximizing, counter)
        )

    if maximizing:
        return max(values)
    return min(values)


def alpha_beta(node, maximizing, alpha, beta, counter):
    if node in LEAF_VALUES:
        counter[0] += 1
        return LEAF_VALUES[node]

    if maximizing:
        value = float("-inf")

        for child in TREE[node]:
            child_value = alpha_beta(
                child, False, alpha, beta, counter
            )
            value = max(value, child_value)
            alpha = max(alpha, value)

            if alpha >= beta:
                break

        return value

    else:
        value = float("inf")

        for child in TREE[node]:
            child_value = alpha_beta(
                child, True, alpha, beta, counter
            )
            value = min(value, child_value)
            beta = min(beta, value)

            if alpha >= beta:
                break

        return value


def main():
    minimax_counter = [0]
    minimax_result = minimax(
        "Root", True, minimax_counter
    )

    alpha_beta_counter = [0]
    alpha_beta_result = alpha_beta(
        "Root",
        True,
        float("-inf"),
        float("inf"),
        alpha_beta_counter
    )

    print("=" * 40)
    print("MINIMAX ALGORITHM")
    print("=" * 40)
    print("Best Value:", minimax_result)
    print("Evaluated Leaves:", minimax_counter[0])

    print("\n" + "=" * 40)
    print("ALPHA-BETA PRUNING")
    print("=" * 40)
    print("Best Value:", alpha_beta_result)
    print("Evaluated Leaves:", alpha_beta_counter[0])

    print("\n" + "=" * 40)
    print("COMPARISON")
    print("=" * 40)
    print(
        "Both algorithms agree:",
        minimax_result == alpha_beta_result
    )
    print(
        "Leaves saved:",
        minimax_counter[0] - alpha_beta_counter[0]
    )


if __name__ == "__main__":
    main()