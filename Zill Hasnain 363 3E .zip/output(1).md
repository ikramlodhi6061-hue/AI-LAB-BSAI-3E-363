AI Lab: Minimax and Alpha-Beta Pruning
Illustrative tree leaf values: {'A1': 3, 'A2': 5, 'B1': 6, 'B2': 9}

--- MINIMAX ---
Evaluate leaf A1 = 3
Evaluate leaf A2 = 5
MIN node A returns 3
Evaluate leaf B1 = 6
Evaluate leaf B2 = 9
MIN node B returns 6
MAX node Root returns 6
Root value: 6
Evaluated leaves: 4

--- ALPHA-BETA PRUNING ---
Evaluate leaf A1 = 3
Evaluate leaf A2 = 5
MIN node A returns 3
Evaluate leaf B1 = 6
Evaluate leaf B2 = 9
MIN node B returns 6
MAX node Root returns 6
Root value: 6
Evaluated leaves: 4

--- VERIFICATION ---
Root values agree: True
Leaves saved by alpha-beta: 0
