# AI Lab Assignment — Minimax and Alpha-Beta Pruning

## Files
- `minimax_alpha_beta.py` — Python implementation of Minimax and Alpha-Beta pruning, with terminal-leaf counters.
- `Minimax_AlphaBeta_Report.docx` — written assignment and explanation.
- `output.txt` — captured program output.

## Run
Requires Python 3.8+ and no third-party packages.

```bash
python minimax_alpha_beta.py
```

## Important note about the tree
The provided screenshot lists the tasks but does not show the supplied game tree or its terminal values. To make the assignment runnable, this package uses a clearly labelled illustrative tree with leaf values 3, 5, 6, and 9. Before submitting, compare these values and the tree structure with the actual tree in your lab manual and update `TREE` and `LEAF_VALUES` if needed.

## What the program checks
- Both algorithms calculate the root value.
- Each algorithm counts terminal leaves actually evaluated.
- Alpha-Beta pruning stops exploring a branch when `alpha >= beta`.
- Both algorithms must return the same root value for the same tree.
