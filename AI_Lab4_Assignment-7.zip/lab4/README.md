# AI Lab 4 — Informed Search: Heuristics & A*

## Files
- `lab4_astar_audit.py` — A* and UCS implementation, trace, path-cost verification, heuristic audit, and overestimate experiment.
- `Lab4_Report.docx` — written report addressing the three lab tasks.
- `output.txt` — captured output from running the program.

## Requirements
- Python 3.8 or newer
- No third-party packages are required.

## Run
Open a terminal in this folder and run:

```bash
python lab4_astar_audit.py
```

## Experiment summary
The supplied heuristic returns `S -> A -> C -> G` with cost 6. The UCS control also returns cost 6. When only `h(C)` is changed from 2 to 10, A* returns `S -> B -> G` with cost 9, illustrating why an inadmissible heuristic can lose the optimality guarantee.

## Reproducibility and attribution
The graph, heuristic values, task requirements, and counting convention are taken from the provided AI Lab Manual, Lab 4. The implementation is written for this assignment and uses Python's standard-library `heapq` priority queue. No external datasets are used.
