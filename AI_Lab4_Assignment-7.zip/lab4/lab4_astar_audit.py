"""
AI Lab 4: Informed Search — Heuristics & A*
Implements A* and Uniform Cost Search (UCS) on the supplied campus graph.
Expansion convention: a node is expanded when its successors are examined.
The goal is logged as processed but is not counted as expanded.
"""

import heapq


def search(graph, heuristic, start, goal):
    """Run A*; set every heuristic value to 0 to run UCS."""
    priority_queue = [(heuristic[start], 0, start, [start])]
    best_cost = {start: 0}
    processed_trace = []
    expanded_nodes = []

    while priority_queue:
        f, g, node, path = heapq.heappop(priority_queue)

        # Ignore queue entries that no longer represent the best path.
        if g != best_cost.get(node, float("inf")):
            continue

        processed_trace.append((node, g, heuristic[node], f))

        if node == goal:
            return {
                "path": path,
                "cost": g,
                "processed_trace": processed_trace,
                "expanded_nodes": expanded_nodes,
                "expansion_count": len(expanded_nodes),
            }

        expanded_nodes.append(node)
        for neighbor, weight in graph.get(node, []):
            new_cost = g + weight
            if new_cost < best_cost.get(neighbor, float("inf")):
                best_cost[neighbor] = new_cost
                heapq.heappush(
                    priority_queue,
                    (new_cost + heuristic[neighbor], new_cost,
                     neighbor, path + [neighbor])
                )

    return {
        "path": None, "cost": float("inf"),
        "processed_trace": processed_trace,
        "expanded_nodes": expanded_nodes,
        "expansion_count": len(expanded_nodes),
    }


def print_result(label, result):
    print(f"--- {label} ---")
    print("Path:", " -> ".join(result["path"]) if result["path"] else "No path")
    print("Returned path cost:", result["cost"])
    print("Processed trace (node, g, h, f):")
    for row in result["processed_trace"]:
        print(" ", row)
    print("Expanded nodes:", result["expanded_nodes"])
    print("Expansion count (goal excluded):", result["expansion_count"])
    # Independently verify the returned path cost against the graph.
    if result["path"]:
        # The cost is independently recomputed below by the caller.
        print("Independent path-cost check: see verification below")
    print()


def independently_sum_path(graph, path):
    total = 0
    for u, v in zip(path, path[1:]):
        for neighbor, weight in graph.get(u, []):
            if neighbor == v:
                total += weight
                break
        else:
            raise ValueError(f"No edge found for {u} -> {v}")
    return total


def main():
    graph = {
        "S": [("A", 1), ("B", 4)],
        "A": [("C", 2)],
        "B": [("G", 5)],
        "C": [("G", 3)],
        "G": [],
    }
    supplied_h = {"S": 5, "A": 4, "B": 4, "C": 2, "G": 0}
    zero_h = {node: 0 for node in graph}

    print("AI Lab 4 — A* Heuristic Audit and UCS Comparison")
    print("Graph:", graph)
    print("Supplied heuristic:", supplied_h)
    print()
    astar_result = search(graph, supplied_h, "S", "G")
    ucs_result = search(graph, zero_h, "S", "G")
    over_h = dict(supplied_h)
    over_h["C"] = 10
    overestimate_result = search(graph, over_h, "S", "G")

    print_result("A* with supplied heuristic", astar_result)
    print("Independent path cost:", independently_sum_path(graph, astar_result["path"]))
    print()
    print_result("UCS control (h = 0)", ucs_result)
    print("Independent path cost:", independently_sum_path(graph, ucs_result["path"]))
    print()
    print_result("A* with overestimate h(C) = 10", overestimate_result)
    print("Independent path cost:", independently_sum_path(graph, overestimate_result["path"]))
    print()

    true_remaining = {"S": 6, "A": 5, "B": 5, "C": 3, "G": 0}
    print("Heuristic audit:")
    for node in graph:
        print(f"  {node}: supplied h={supplied_h[node]}, true remaining cost="
              f"{true_remaining[node]}, admissible at node="
              f"{supplied_h[node] <= true_remaining[node]}")
    print("Consistency checks h(u) <= cost(u,v) + h(v):")
    all_consistent = True
    for u, edges in graph.items():
        for v, weight in edges:
            passes = supplied_h[u] <= weight + supplied_h[v]
            all_consistent &= passes
            print(f"  {u}->{v}: {supplied_h[u]} <= {weight} + "
                  f"{supplied_h[v]} = {weight + supplied_h[v]} : {passes}")
    print("Supplied heuristic consistent:", all_consistent)


if __name__ == "__main__":
    main()
